package org.mcsg.survivalgames.util;

public class TrapsGen {

}