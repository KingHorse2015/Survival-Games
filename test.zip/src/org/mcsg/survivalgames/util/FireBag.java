package org.mcsg.survivalgames.util;

public class FireBag {

}