package org.mcsg.survivalgames.events;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.mcsg.survivalgames.Game;
import org.mcsg.survivalgames.GameManager;
import org.mcsg.survivalgames.SettingsManager;

public class BreakEvent implements Listener {

	public ArrayList<Material> allowedBreak = new ArrayList<Material>();;

	// Config loads integer ID list, convert it to Material
	@SuppressWarnings("deprecation")
	public BreakEvent() {
		List<Integer> ids = SettingsManager.getInstance().getConfig().getIntegerList("block.break.whitelist");
		for (Integer i : ids) {
			allowedBreak.add(Material.getMaterial(i));
		}
	}

	@EventHandler(priority = EventPriority.HIGHEST)
	public void onBlockBreak(BlockBreakEvent event) {
		Player p = event.getPlayer();
		int id = GameManager.getInstance().getPlayerGameId(p);

		if (id == -1) {
			int gameblockid = GameManager.getInstance().getBlockGameId(event.getBlock().getLocation());
			if (gameblockid != -1) {
				if (GameManager.getInstance().getGame(gameblockid).getGameMode() != Game.GameMode.DISABLED) {
					event.setCancelled(true);
				}
			}
			return;
		}

		Game g = GameManager.getInstance().getGame(id);
		if (g.isPlayerinactive(p)) {
			return;
		}
		if (g.getMode() == Game.GameMode.DISABLED) {
			return;
		}
		if (g.getMode() != Game.GameMode.INGAME) {
			event.setCancelled(true);
			return;
		}

		if (!allowedBreak.contains(event.getBlock().getType())) {
			event.setCancelled(true);
		}
	}
}