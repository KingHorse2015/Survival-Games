package org.mcsg.survivalgames.hooks;

public interface HookBase {

	public void executehook(String player, String[] s2);

}
